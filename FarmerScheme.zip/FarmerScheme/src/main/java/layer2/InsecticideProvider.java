package layer2;

import java.util.ArrayList;

public class InsecticideProvider {
	
	private long InsecticideProviderId;
	private String InsecticideProviderName;
	private long Contact;
	private String Email;
	private String CompanyName;
	private float InsecticideProviderRating;
    ArrayList<Insecticide> Insecticides;
    
    
	
	public InsecticideProvider() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public long getInsecticideProviderId() {
		return InsecticideProviderId;
	}
	public void setInsecticideProviderId(long insecticideProviderId) {
		InsecticideProviderId = insecticideProviderId;
	}
	public String getInsecticideProviderName() {
		return InsecticideProviderName;
	}
	public void setInsecticideProviderName(String insecticideProviderName) {
		InsecticideProviderName = insecticideProviderName;
	}
	public long getContact() {
		return Contact;
	}
	public void setContact(long contact) {
		Contact = contact;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public float getInsecticideProviderRating() {
		return InsecticideProviderRating;
	}
	public void setInsecticideProviderRating(float insecticideProviderRating) {
		InsecticideProviderRating = insecticideProviderRating;
	}
	public ArrayList<Insecticide> getInsecticides() {
		return Insecticides;
	}
	public void setInsecticides(ArrayList<Insecticide> insecticides) {
		Insecticides = insecticides;
	}
	@Override
	public String toString() {
		return "InsecticideProvider [InsecticideProviderId=" + InsecticideProviderId + ", InsecticideProviderName="
				+ InsecticideProviderName + ", Contact=" + Contact + ", Email=" + Email + ", CompanyName=" + CompanyName
				+ ", InsecticideProviderRating=" + InsecticideProviderRating + ", Insecticides=" + Insecticides + "]";
	}
    
    
    
    
	
	
	

}
