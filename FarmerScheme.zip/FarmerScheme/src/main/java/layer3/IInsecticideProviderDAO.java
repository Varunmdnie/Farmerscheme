package layer3;

import java.util.List;


import layer2.InsecticideProvider;

public interface IInsecticideProviderDAO {
	

	InsecticideProvider selectInsecticideProvider(int InsecticideProviderId);
	List<InsecticideProvider> selectAllInsecticideProvider();
	
	void insertInsecticideProvider(InsecticideProvider insecticideprovider);
	void updateInsecticideProvider(InsecticideProvider insecticideprovider);
	void deleteInsecticideProvider(int InsecticideProviderId);

}
