package layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import layer2.Insecticide;

public class InsecticideDAOImpl implements IInsecticideDAO {
	Connection conn;

	public InsecticideDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://localhost/mysql", "root", "root123");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}


	@Override
	public Insecticide selectInsecticide(int InsecticideId) {
		Insecticide insecticide= null;
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result= statement.executeQuery("SELECT*from Insecticide where InsecticideId="+InsecticideId);
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");
			
			if(result.next())
			{
				insecticide= new Insecticide();
				insecticide.setInsecticideId(result.getInt(1));
				insecticide.setInsecticideName(result.getString(2));
				insecticide.setPrice(result.getFloat(3));
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return insecticide;
	}

	@Override
	public List<Insecticide> selectAllInsecticide() {
		List<Insecticide> InsecticideList= new ArrayList<Insecticide>();
		
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM Insecticide"); //eid, ename, job, sal    cid,cname,city,pin
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");
			
			while(result.next())
			{
				Insecticide insecticide= new Insecticide();
				insecticide.setInsecticideId(result.getInt(1));
				insecticide.setInsecticideName(result.getString(2));
				insecticide.setPrice(result.getFloat(3));
				InsecticideList.add(insecticide);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return InsecticideList;
	}

	@Override
	public void insertInsecticide(Insecticide insecticide) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into Insecticide(InsecticideId,InsecticideName,price) values(?,?,?)");
			System.out.println("3. PreparedStatement created....");
			pst.setInt(1, insecticide.getInsecticideId());
			pst.setString(2, insecticide.getInsecticideName());
			
			pst.setFloat(3, insecticide.getPrice());

			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void updateInsecticide(Insecticide insecticide) {
		try {
			PreparedStatement pst = conn.prepareStatement("update Insecticide InsecticideId=?,InsecticideName = ?,price=?");
			System.out.println("3. PreparedStatement created....");
			pst.setInt(1, insecticide.getInsecticideId());
			pst.setString(2, insecticide.getInsecticideName());
			
			pst.setFloat(3, insecticide.getPrice());

			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	

	@Override
	public void deleteInsecticide(int InsecticideId) {
		
		try {
			PreparedStatement pst = conn.prepareStatement("delete from Insecticide where InsecticideId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setInt(1, InsecticideId);
			
			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the delete query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}
	

	}


