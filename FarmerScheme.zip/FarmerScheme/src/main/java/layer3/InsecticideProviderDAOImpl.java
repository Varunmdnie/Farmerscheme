package layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import layer2.InsecticideProvider;

public class InsecticideProviderDAOImpl implements IInsecticideProviderDAO {
	Connection conn;

	public InsecticideProviderDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://localhost/mysql", "root", "root123");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public InsecticideProvider selectInsecticideProvider(int InsecticideProviderId) {
		
		
        InsecticideProvider insecticideprovider = null;
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result= statement.executeQuery("SELECT*from InsecticideProvider where InsecticideProviderId="+InsecticideProviderId);
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");
			
			if(result.next())
			{
				insecticideprovider= new InsecticideProvider();
				insecticideprovider.setInsecticideProviderId(result.getLong(1));
				insecticideprovider.setInsecticideProviderName(result.getString(2));
				insecticideprovider.setContact(result.getLong(3));
				insecticideprovider.setEmail(result.getString(4));
				insecticideprovider.setCompanyName(result.getString(5));
				insecticideprovider.setInsecticideProviderRating(6);
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return insecticideprovider;
		
	}

	@Override
	public List<InsecticideProvider> selectAllInsecticideProvider() {
	 List<InsecticideProvider> InsecticideProviderList = new ArrayList<InsecticideProvider>();
	 
	 try {
		Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM InsecticideProvider"); //eid, ename, job, sal    cid,cname,city,pin
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");
			
			while(result.next())
			{
				InsecticideProvider insecticideprovider= new InsecticideProvider();
				insecticideprovider.setInsecticideProviderId(result.getLong(1));
				insecticideprovider.setInsecticideProviderName(result.getString(2));
				insecticideprovider.setContact(result.getLong(3));
				insecticideprovider.setEmail(result.getString(4));
				insecticideprovider.setCompanyName(result.getString(5));
				insecticideprovider.setInsecticideProviderRating(result.getFloat(6));
				InsecticideProviderList.add(insecticideprovider);
				
			}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		return InsecticideProviderList;
	}

	@Override
	public void insertInsecticideProvider(InsecticideProvider insecticideprovider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateInsecticideProvider(InsecticideProvider insecticideprovider) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteInsecticideProvider(int InsecticideProviderId) {
		// TODO Auto-generated method stub
		
	}

}
