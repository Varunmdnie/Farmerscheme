package com.java.layer2;

public class Crop {
	int cropId;
	String cropName;
	
	public Crop(int cropId, String cropName) {
		super();
		this.cropId = cropId;
		this.cropName = cropName;
	}
	public int getCropId() {
		return cropId;
	}
	public String getCropName() {
		return cropName;
	}
	public void setCropId(int cropId) {
		this.cropId = cropId;
	}
	public void setCropName(String cropName) {
		this.cropName = cropName;
	}
	@Override
	public String toString() {
		return "Crop [cropId=" + cropId + ", cropName=" + cropName + "]";
	}
	
}
