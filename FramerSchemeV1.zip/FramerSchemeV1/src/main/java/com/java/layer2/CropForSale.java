package com.java.layer2;

import java.sql.Date;


public class CropForSale {

	
	int cropId;
	String cropName;
	long cropForSaleId;
	float quantity;
	float minimumPrice;
	long farmerId;
	Date timeUpload;
	
	public CropForSale(String cropName,  long cropForSaleId, float quantity, float minimumPrice,long farmerId,
			Date timeUpload) {
		this.cropName=cropName;
		this.cropForSaleId = cropForSaleId;
		this.quantity = quantity;
		this.minimumPrice = minimumPrice;
		this.farmerId=farmerId;
		this.timeUpload = timeUpload;
	}
	
    
	public int getCropId() {
		return cropId;
	}
	
    public void setCropId(int cropId) {
		this.cropId = cropId;
	}


	public CropForSale() {
		super();
	}


	public String getCropName() {
		return cropName;
	}

	public void setCropName(String cropName) {
		this.cropName = cropName;
	}

	public long getCropForSaleId() {
		return cropForSaleId;
	}
	

	public void setCropForSaleId(long cropForSaleId) {
		this.cropForSaleId = cropForSaleId;
	}


	public float getQuantity() {
		return quantity;
	}

	public float getMinimumPrice() {
		return minimumPrice;
	}

	public Date getTimeUpload() {
		return timeUpload;
	}

	

	public void setQuantity(float quantity) {
		this.quantity = quantity;
	}
	
	

	public void setMinimumPrice(float minimumPrice) {
		this.minimumPrice = minimumPrice;
	}

	public void setTimeUpload(Date timeUpload) {
		this.timeUpload = timeUpload;
	}

	public long getFarmerId() {
		return farmerId;
	}

	public void setFarmerId(long farmerId) {
		this.farmerId = farmerId;
	}


	@Override
	public String toString() {
		return "CropForSale [cropId=" + cropId + ", cropName=" + cropName + ", cropForSaleId=" + cropForSaleId
				+ ", quantity=" + quantity + ", minimumPrice=" + minimumPrice + ", farmerId=" + farmerId
				+ ", timeUpload=" + timeUpload + "]";
	}
	

	
	
	
	
	

}
