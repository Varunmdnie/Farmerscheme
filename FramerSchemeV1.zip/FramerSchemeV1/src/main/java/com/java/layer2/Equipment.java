package com.java.layer2;

public class Equipment {
	private int equipmentId;
	private String equipmentName;
	private float price;
	
	
	public Equipment() {
		System.out.println("Equipment Constructor.............");
	}


	public int getEquipmentId() {
		return equipmentId;
	}


	public void setEquipmentId(int equipmentId) {
		this.equipmentId = equipmentId;
	}


	public String getEquipmentName() {
		return equipmentName;
	}


	public void setEquipmentName(String equipmentName) {
		this.equipmentName = equipmentName;
	}


	public float getPrice() {
		return price;
	}


	public void setPrice(float price) {
		this.price = price;
	}


	@Override
	public String toString() {
		return "Equipment [toString()=" + super.toString() + ", equipmentId=" + equipmentId + ", equipmentName="
				+ equipmentName + ", price=" + price + "]";
	}
	
	
}
