package com.java.layer2;

public class Insecticide {
	private int InsecticideId;
	private String InsecticideName;
	private float Price;
	

	
	public Insecticide() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getInsecticideId() {
		return InsecticideId;
	}
	public void setInsecticideId(int insecticideId) {
		InsecticideId = insecticideId;
	}
	public String getInsecticideName() {
		return InsecticideName;
	}
	public void setInsecticideName(String insecticideName) {
		InsecticideName = insecticideName;
	}
	public float getPrice() {
		return Price;
	}
	public void setPrice(float price) {
		Price = price;
	}
	@Override
	public String toString() {
		return "Insecticide [InsecticideId=" + InsecticideId + ", InsecticideName=" + InsecticideName + ", Price="
				+ Price + "]";
	}
	
	
}
