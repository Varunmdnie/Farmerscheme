package com.java.layer2;

public class InsecticideProviderAndInsecticide {
	
	private int InsecticideId;
	private long InsecticideProviderId;
	
	
	public InsecticideProviderAndInsecticide() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getInsecticideId() {
		return InsecticideId;
	}


	public void setInsecticideId(int insecticideId) {
		InsecticideId = insecticideId;
	}


	public long getInsecticideProviderId() {
		return InsecticideProviderId;
	}


	public void setInsecticideProviderId(long insecticideProviderId) {
		InsecticideProviderId = insecticideProviderId;
	}

}
