package com.java.layer2;

import java.sql.Date;

public class SuccessfulTransaction {
	
	long transactionId;
	long bidId;
	Date transactionDate;
	
	public long getTransactionId() {
		return transactionId;
	}

	public long getBidId() {
		return bidId;
	}

	public void setBidId(long bidId) {
		this.bidId = bidId;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public SuccessfulTransaction(long transactionId, long bidId, Date transactionDate) {
		super();
		this.transactionId = transactionId;
		this.bidId = bidId;
		this.transactionDate = transactionDate;
	}

	public SuccessfulTransaction() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "SuccessfulTransaction [transactionId=" + transactionId + ", bidId=" + bidId + ", transactionDate="
				+ transactionDate + "]";
	}

}
