package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.Bid;

public class BidDAOImpl implements IBidDAO {
	
	Connection conn;

	public BidDAOImpl() {
		// TODO Auto-generated constructor stub
		try {
			
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			System.out.println("Trying to connect to database....");
			conn = DriverManager.getConnection("jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
			System.out.println("Database connected....");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void insertBid(Bid e) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO Bids (bidId,bidderId,cropForSaleId,amount) VALUES (?,?,?,?);");
			
			preparedStatement.setLong(1,e.getBidId());
			preparedStatement.setLong(1,e.getBidderId());
			preparedStatement.setLong(1,e.getCropForSaleId());
			preparedStatement.setFloat(1,e.getAmount());
			
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the insert query : "+rows+ " row(s) inserted");
			
			preparedStatement.close();			
		} catch (SQLException err) {
			// TODO Auto-generated catch block
			err.printStackTrace();
		}
		
	}

	@Override
	public List<Bid> selectAllBids() {
		// TODO Auto-generated method stub
		ArrayList<Bid> bids = new ArrayList<Bid>();
		try {
			Statement statement = conn.createStatement();
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM bids;");
			
			while(result.next()) {
				long bidId =  result.getLong(1);
				long bidderId = result.getLong(2);
				long cropForSaleId = result.getLong(3);
				float amount = result.getFloat(4);
				
				Bid temp = new Bid(bidId,bidderId,cropForSaleId,amount);
				bids.add(temp);
			}
			
			result.close();
			
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bids;
	}

	@Override
	public Bid selectBid(long bidId) {
		// TODO Auto-generated method stub
		Bid res = null;
		try {
			Statement statement = conn.createStatement();
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM bids WHERE bidId = " + bidId + ";");
			
			bidId = 0;
			long bidderId = 0;
			long cropForSaleId = 0;
			float amount = 0f;
			int flag = 0;
			while(result.next()) {
				flag = 1;
				bidId =  result.getLong(1);
				bidderId = result.getLong(2);
				cropForSaleId = result.getLong(3);
				amount = result.getFloat(4);
			}
			
			if(flag==0) {
				System.out.println("No bids found with given Id");
				res = null;
			}
			else {
				System.out.println("Bid found with given Id");
				res = new Bid(bidId,bidderId,cropForSaleId,amount);
			}
			
			result.close();
			
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public void updateBid(Bid e) {
		// TODO Auto-generated method stub
		long bidId = e.getBidId();
		long bidderId = e.getBidderId();
		long cropForSaleId = e.getCropForSaleId();
		float amount = e.getAmount();
		
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("UPDATE bids SET bidderId=?,cropForSaleId=?,amount=? WHERE bidId=?");
			
			
			preparedStatement.setLong(1,bidderId);
			preparedStatement.setLong(2,cropForSaleId);
			preparedStatement.setFloat(3,amount);
			preparedStatement.setLong(4,bidId);
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the update query : "+rows+ " row(s) updated");
			
			preparedStatement.close();			
		} catch (SQLException err) {
			// TODO Auto-generated catch block
			err.printStackTrace();
		}

	}

	@Override
	public void deleteBid(long bidId) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM bids WHERE bidId=?");
			preparedStatement.setLong(1,bidId);
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the delete query : "+rows+ " row(s) deleted");
			
			preparedStatement.close();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
