package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.EquipmentProvider;

public class EquipmentProviderDAOImpl implements IEquipmentProviderDAO {
	Connection conn;

	public EquipmentProviderDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public EquipmentProvider selectEquipmentProvider(long equipmentProviderId) {
		EquipmentProvider equipmentProvider= null;
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM equipmentProvider where equipmentProviderId="+equipmentProviderId); 
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			if (result.next()) {
				equipmentProvider = new EquipmentProvider();
				equipmentProvider.setEquipmentProviderId(result.getLong(1));
				equipmentProvider.setEquipmentProviderName(result.getString(2));
				equipmentProvider.setContact(result.getLong(3));
				equipmentProvider.setEmailId(result.getString(4));
				equipmentProvider.setCompanyName(result.getString(5));
				equipmentProvider.setEquipmentProviderRating(result.getFloat(6));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return equipmentProvider;
		
	}

	@Override
	public List<EquipmentProvider> selectAllequipmentProviders() {
		List<EquipmentProvider> equipmentProviderList = new ArrayList<EquipmentProvider>();
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM equipmentProvider");
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			while (result.next()) {
				EquipmentProvider equipmentProvider = new EquipmentProvider();
				equipmentProvider.setEquipmentProviderId(result.getLong(1)); 
				equipmentProvider.setEquipmentProviderName(result.getString(2));
				equipmentProvider.setContact(result.getLong(3));
				equipmentProvider.setEmailId(result.getString(4));
				equipmentProvider.setCompanyName(result.getString(5));
				equipmentProvider.setEquipmentProviderRating(result.getFloat(6));
				equipmentProviderList.add(equipmentProvider);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return equipmentProviderList;
	}

	@Override
	public void insertEquipmentProvider(EquipmentProvider equipmentProvider) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into equipmentProvider(equipmentProvider_name,contact,email_id,company_name,equipmentProvider_rating) values(?,?,?,?,?)");
			System.out.println("3. PreparedStatement created....");

			
			//pst.setInt(1, equipmentProvider.getEquipmentProviderId());
			
			pst.setString(1, equipmentProvider.getEquipmentProviderName());
			pst.setLong(2, equipmentProvider.getContact());
			pst.setString(3, equipmentProvider.getEmailId());
			pst.setString(4, equipmentProvider.getCompanyName());
			pst.setFloat(5, equipmentProvider.getEquipmentProviderRating());

			int rows = pst.executeUpdate(); 
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public void updateEquipmentProvider(EquipmentProvider equipmentProvider) {
		try {
			PreparedStatement pst = conn.prepareStatement("UPDATE EQUIPMENTPROVIDER set equipmentProvider_name=?, contact=?, email_id=?, company_name=?,equipmentProvider_rating=? where equipmentProviderId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setString(1, equipmentProvider.getEquipmentProviderName());
			pst.setLong(2, equipmentProvider.getContact());
			pst.setString(3, equipmentProvider.getEmailId());
			pst.setString(4, equipmentProvider.getCompanyName());
			pst.setFloat(5, equipmentProvider.getEquipmentProviderRating());

			int rows = pst.executeUpdate();
			
			System.out.println("4. executed the update query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}

	@Override
	public void deleteEquipmentProvider(long equipmentProviderId) {
		try {
			PreparedStatement pst = conn.prepareStatement("DELETE FROM EQUIPMENTPROVIDER  where equipmentProviderId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setLong(1, equipmentProviderId);
			
			int rows = pst.executeUpdate();
			
			System.out.println("4. executed the delete query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}


}
