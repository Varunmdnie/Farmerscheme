package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.java.layer2.FarmerAndCrop;

public class FarmerAndCropDAOImpl implements IFarmerAndCropDAO {

	Connection conn;
	
	public FarmerAndCropDAOImpl() {
		// TODO Auto-generated constructor stub
		try {
			
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			
			System.out.println("Trying to connect to database....");
			conn = DriverManager.getConnection(
	                "jdbc:mysql://localhost/FarmerSchemeV1", "root", "root123");
			System.out.println("Database connected....");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void insertFarmerAndCrop(FarmerAndCrop e) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("INSERT INTO FarmerAndCrop (farmerId,cropId) VALUES (?,?);");
			
			preparedStatement.setLong(1,e.getFarmerId());
			preparedStatement.setInt(2,e.getCropId());
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the insert query : "+rows+ " row(s) inserted");
			
			preparedStatement.close();			
		} catch (SQLException err) {
			// TODO Auto-generated catch block
			err.printStackTrace();
		}

	}

	@Override
	public List<FarmerAndCrop> selectAllFarmerAndCrops() {
		// TODO Auto-generated method stub
		ArrayList<FarmerAndCrop> farmerAndCrops = new ArrayList<FarmerAndCrop>();
		try {
			Statement statement = conn.createStatement();
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM FarmerAndCrop;");
			
			while(result.next()) {
				long farmerId =  result.getLong(1);
				int cropId = result.getInt(2);
				
				FarmerAndCrop temp = new FarmerAndCrop(farmerId, cropId);
				farmerAndCrops.add(temp);
				
			}
			
			result.close();
			
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return farmerAndCrops;
	}

	@Override
	public FarmerAndCrop selectFarmerAndCrop(long farmerId, int cropId) {
		// TODO Auto-generated method stub
		FarmerAndCrop res = null;
		try {
			Statement statement = conn.createStatement();
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM FarmerAndCrop WHERE farmerId = " + farmerId + " AND cropId = " + cropId + ";");
			
			int flag=0;
			while(result.next()) {
				flag = 1;
				farmerId =  result.getLong(1);
				cropId =  result.getInt(2);
				
			}
			
			if(flag==0) {
				System.out.println("No FarmerAndCrop found with given Id");
				res = null;
			}
			else {
				System.out.println("FarmerAndCrop found with given Id");
				res = new FarmerAndCrop(farmerId, cropId);
			}
			
			result.close();
			
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

	@Override
	public void updateFarmerAndCrop(FarmerAndCrop e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteFarmerAndCrop(long farmerId, int cropId) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM FarmerAndCrop WHERE farmerId=? AND cropId=?");
			preparedStatement.setLong(1,farmerId);
			preparedStatement.setInt(1,cropId);
			
			int rows = preparedStatement.executeUpdate(); //run the insert query
			
			System.out.println("Executed the delete query : "+rows+ " row(s) deleted");
			
			preparedStatement.close();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
