package com.java.layer3;

import java.util.List;

import com.java.layer2.Crop;

public interface ICropDAO {
	    Crop selectCrop(int cropId );
		List<Crop> selectAllCrops();
		
		void insertCrop(Crop crop);
		void updateCrop(Crop crop);
		void deleteCrop(int cropId);
		Crop selectCropByName(String cropName );
}
