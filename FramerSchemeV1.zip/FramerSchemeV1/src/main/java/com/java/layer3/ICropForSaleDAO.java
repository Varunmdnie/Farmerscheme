package com.java.layer3;

import java.util.List;

import com.java.layer2.CropForSale;

public interface ICropForSaleDAO  {
	
	CropForSale selectCropForSale(long cropForSaleId );
	List<CropForSale> selectAllCropsForSale();
	
	void insertCropForSale(CropForSale cropForSale);
	void updateCropForSale(CropForSale cropForSale);
	void deleteCropForSale(long cropForSale);
	
	
    
}
