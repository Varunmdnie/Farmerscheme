package com.java.layer3;
import java.util.List;
import com.java.layer2.EquipmentProviderAndEquipment;

public interface IEquipmentProviderAndEquipmentDAO {

	EquipmentProviderAndEquipment selectEquipmentProviderAndEquipment(int equipmentId,long equipmentProviderId);
	List<EquipmentProviderAndEquipment> selectAllEquipmentProviderAndEquipments();
	
	void insertEquipmentProviderAndEquipment(EquipmentProviderAndEquipment equipmentProviderAndEquipment);
	void updateEquipmentProviderAndEquipmentt(EquipmentProviderAndEquipment equipmentProviderAndEquipment);
	void deleteEquipmentProviderAndEquipment(int equipmentId,long equipmentProviderId);
}
