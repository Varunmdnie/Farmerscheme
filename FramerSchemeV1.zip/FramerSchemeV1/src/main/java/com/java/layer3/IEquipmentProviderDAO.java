package com.java.layer3;

import java.util.List;

import com.java.layer2.EquipmentProvider;

public interface IEquipmentProviderDAO {

	EquipmentProvider selectEquipmentProvider(long equipmentProviderId);
	List<EquipmentProvider> selectAllequipmentProviders();
	
	void insertEquipmentProvider(EquipmentProvider equipmentProvider);
	void updateEquipmentProvider(EquipmentProvider equipmentProvider);
	void deleteEquipmentProvider(long equipmentProviderId);

}
