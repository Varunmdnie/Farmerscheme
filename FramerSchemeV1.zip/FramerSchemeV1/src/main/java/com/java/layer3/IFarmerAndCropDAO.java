package com.java.layer3;

import java.util.List;

import com.java.layer2.FarmerAndCrop;

public interface IFarmerAndCropDAO {
	public void insertFarmerAndCrop(FarmerAndCrop e);
	public List<FarmerAndCrop> selectAllFarmerAndCrops();
	public FarmerAndCrop selectFarmerAndCrop(long farmerId,int cropId);
	public void updateFarmerAndCrop(FarmerAndCrop e);
	public void deleteFarmerAndCrop(long farmerId,int cropId);
}
