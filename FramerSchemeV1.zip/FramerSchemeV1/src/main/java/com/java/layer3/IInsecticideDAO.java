package com.java.layer3;

import java.util.List;



import com.java.layer2.Insecticide;

public interface IInsecticideDAO {
	
	Insecticide selectInsecticide(int InsecticideId);
	List<Insecticide> selectAllInsecticide();
	
	void insertInsecticide(Insecticide insecticide);
	void updateInsecticide(Insecticide insecticide);
	void deleteInsecticide(int InsecticideId);

}
