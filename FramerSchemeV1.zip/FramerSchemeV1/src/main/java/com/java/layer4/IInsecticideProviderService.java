package com.java.layer4;

import java.util.List;

import com.java.layer2.InsecticideProvider;

public interface IInsecticideProviderService {

	InsecticideProvider findInsecticideProviderService(long insecticideProviderId);
	List<InsecticideProvider> findAllInsecticideProvider();
	void saveInsecticideProviderService(InsecticideProvider insecticideProviderToAdd) throws InsecticideProviderAlreadyExsists;
	void modifyInsecticideProviderService(InsecticideProvider insecticideProviderToModify) throws InsecticideProviderNotFound;
	void removeInsecticideProviderService( long insecticideProviderId );
	

}
