package com.java.layer4;

import java.util.List;



import com.java.layer2.Insecticide;

public interface IInsecticideService {
	
	Insecticide findInsecticideService(int insecticideId) throws InsecticideNotFound;
	List<Insecticide> findAllInsecticide();
	void saveInsecticideService(Insecticide insecticideToAdd) throws InsecticideAlreadyExsists;
	void modifyInsecticideService(Insecticide insecticideToModify) throws InsecticideNotFound;
	void removeInsecticideService( int insecticideId );
	

}
 