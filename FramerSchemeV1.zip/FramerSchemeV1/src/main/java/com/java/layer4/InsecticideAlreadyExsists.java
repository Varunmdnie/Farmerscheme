package com.java.layer4;

public class InsecticideAlreadyExsists extends Exception {

	public InsecticideAlreadyExsists(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
