package com.java.layer4;

public class InsecticideNotFound extends Exception {
	public InsecticideNotFound(String s)
	{
		super(s);
	}

}
