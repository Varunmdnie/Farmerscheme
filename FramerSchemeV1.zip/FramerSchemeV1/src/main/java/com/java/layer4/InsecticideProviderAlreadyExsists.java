package com.java.layer4;

public class InsecticideProviderAlreadyExsists extends Exception {

	public InsecticideProviderAlreadyExsists(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
