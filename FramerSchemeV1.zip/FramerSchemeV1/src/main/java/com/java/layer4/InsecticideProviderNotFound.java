package com.java.layer4;

public class InsecticideProviderNotFound extends Exception {

	public InsecticideProviderNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
