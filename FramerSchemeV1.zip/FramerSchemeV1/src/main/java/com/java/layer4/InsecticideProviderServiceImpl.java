package com.java.layer4;

import java.util.List;

import com.java.layer2.InsecticideProvider;
import com.java.layer3.IInsecticideProviderDAO;
import com.java.layer3.InsecticideProviderDAOImpl;

public class InsecticideProviderServiceImpl implements IInsecticideProviderService{

	IInsecticideProviderDAO inspDao = new InsecticideProviderDAOImpl();
	@Override
	public  InsecticideProvider findInsecticideProviderService(long insecticideProviderId) throws InsecticideProviderNotFound {
		

		List<InsecticideProvider> listInsecticideProviders = inspDao.selectAllInsecticideProvider();
		InsecticideProvider in= new InsecticideProvider();
		//in= inspDao.selectInsecticideProvider(insecticideProviderId);
		boolean InsecticideProviderFound= false;
		for(InsecticideProvider insecticidep : listInsecticideProviders) {
			if(insecticidep.getInsecticideProviderId() == insecticideProviderId)
			{
				in= inspDao.selectInsecticideProvider(insecticideProviderId);
				InsecticideProviderFound= true;
				break;
			}
			
			
		}
		if(InsecticideProviderFound==false)
			{throw new InsecticideProviderNotFound("Insecticide not found");}
		else
		{
			return in;
		}
		
	}
	
	


	@Override
	public List<InsecticideProvider> findAllInsecticideProvider() {
		
		List<InsecticideProvider> listInsecticideProviders = inspDao.selectAllInsecticideProvider();
		
		return listInsecticideProviders;
	}

	@Override
	public void saveInsecticideProviderService(InsecticideProvider insecticideProviderToAdd)
			throws InsecticideProviderAlreadyExsists {
		
		List<InsecticideProvider> listInsecticideProviders = inspDao.selectAllInsecticideProvider();
		boolean InsecticideProviderFound= false;
		for(InsecticideProvider insecticideP : listInsecticideProviders) {
			if(insecticideP.getInsecticideProviderId()==(insecticideProviderToAdd.getInsecticideProviderId()))
			{
				InsecticideProviderFound= true;
				break;
			}
			
			
		}
		if(InsecticideProviderFound==true) throw new InsecticideProviderAlreadyExsists("insecticide provider already exists");
		else inspDao.insertInsecticideProvider(insecticideProviderToAdd);
		
	}

	@Override
	public void modifyInsecticideProviderService(InsecticideProvider insecticideProviderToModify)
			throws InsecticideProviderNotFound {
		

		List<InsecticideProvider> listInsecticideProviders = inspDao.selectAllInsecticideProvider();
		boolean InsecticideProviderFound= false;
		for(InsecticideProvider insecticideP : listInsecticideProviders) {
			if(insecticideP.getInsecticideProviderId()==(insecticideProviderToModify.getInsecticideProviderId()))
			{
				InsecticideProviderFound= true;
				break;
			}
			
			
		}
		if(InsecticideProviderFound==false) throw new InsecticideProviderNotFound("Insecticide provider not found");
		else inspDao.updateInsecticideProvider(insecticideProviderToModify);
		
	}

	@Override
	public void removeInsecticideProviderService(long insecticideProviderId) {
		
		inspDao.deleteInsecticideProvider(insecticideProviderId);
		
		
	}

}
