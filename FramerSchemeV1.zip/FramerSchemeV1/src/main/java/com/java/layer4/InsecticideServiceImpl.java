package com.java.layer4;

import java.util.List;

import com.java.layer2.Insecticide;
import com.java.layer3.IInsecticideDAO;
import com.java.layer3.InsecticideDAOImpl;

public class InsecticideServiceImpl  implements IInsecticideService{
	
	IInsecticideDAO insDao = new InsecticideDAOImpl();

	@Override
	public Insecticide findInsecticideService(int insecticideId) throws InsecticideNotFound {

		List<Insecticide> listInsecticides = insDao.selectAllInsecticide();
		boolean InsecticideFound= false;
		for(Insecticide insecticide : listInsecticides) {
			if(insecticide.getInsecticideId() == 0)
			{
				InsecticideFound= true;
				break;
			}
			
			
		}
		if(InsecticideFound==false)
			{throw new InsecticideNotFound("Insecticide not found");}
		return null;
		
		
		



		
	}

	@Override
	public List<Insecticide> findAllInsecticide() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveInsecticideService(Insecticide insecticideToAdd) throws InsecticideAlreadyExsists {
		
		List<Insecticide> listInsecticides = insDao.selectAllInsecticide();
		boolean InsecticideFound= false;
		for(Insecticide insecticide : listInsecticides) {
			if(insecticide.getInsecticideId() == (insecticideToAdd.getInsecticideId()))
			{
				InsecticideFound= true;
				break;
			}
			
			
		}
		if(InsecticideFound==true) throw new InsecticideAlreadyExsists("insecticide already exists");
		else insDao.insertInsecticide(insecticideToAdd);
 	}

	@Override
	public void modifyInsecticideService(Insecticide insecticideToModify) throws InsecticideNotFound {
		
		List<Insecticide> listInsecticides = insDao.selectAllInsecticide();
		boolean InsecticideFound = false;
		for(Insecticide insecticide : listInsecticides)
		{
			if(insecticide.getInsecticideId()==(insecticideToModify.getInsecticideId()))
			{
				InsecticideFound = true;
				break;
			}
		}
		if(InsecticideFound== false) throw new InsecticideNotFound("Insecticide not found");
		else insDao.updateInsecticide(insecticideToModify);
		
				
		
	}

	@Override
	public void removeInsecticideService(int insecticideId) {
	
		
	}

	

}
