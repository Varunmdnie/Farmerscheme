package com.java.layer5;

import java.util.List;

import javax.ws.rs.PathParam;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.java.layer2.Insecticide;
import com.java.layer4.IInsecticideService;
import com.java.layer4.InsecticideAlreadyExsists;
import com.java.layer4.InsecticideNotFound;
import com.java.layer4.InsecticideServiceImpl;



@Path("/Insecticidedb")
public class InsecticideController {

	IInsecticideService insecticideservice= new InsecticideServiceImpl();
	
	
	public InsecticideController() {
		System.out.println("constructor is called");
	}
	

	/*@GET
	@Path("/get/{iid}")
	@Produces(MediaType.APPLICATION_JSON)
	public Insecticide  getIt(@PathParam ("iid")int x)
	{
		Insecticide i = new Insecticide();
		try
		{
		i= 	insecticideservice.findInsecticideService(x);
			
		}
		catch(InsecticideNotFound e)
		{
			e.printStackTrace();
		}
		return i;
	}*/

	@GET
	@Path("/get/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getInsecticide(@PathParam("id") int id) {
		System.out.println("here");
		try {
			Insecticide insecticide = insecticideservice.findInsecticideService(id);
			return Response
					.status(Response.Status.OK)
					.entity(insecticide)
					.build();
		}
		catch(InsecticideNotFound err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	

	@GET
	@Path("/getall")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getallInsecticides(){
		try {
			List<Insecticide> InsecticideList = insecticideservice.findAllInsecticide();
			return Response
					.status(Response.Status.OK)
					.entity(InsecticideList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	
	
	@POST
	@Path("/add")
	@Produces(MediaType.APPLICATION_JSON)
	public String AddIt(Insecticide insobj)
	{
		try
		{
			insecticideservice.saveInsecticideService(insobj);
			return "Insecticide added succesfully";
		}
		catch(InsecticideAlreadyExsists e)
		{
			return e.getMessage();
		}
	}
	
	@PUT
	@Path("/update")
	@Produces(MediaType.APPLICATION_JSON)
	public String ModifyIt(Insecticide insobj)
	{
		try
		{
			insecticideservice.modifyInsecticideService(insobj);
			return "Insecticide  modified";
		}
		catch(InsecticideNotFound e)
		{
			return e.getMessage();
		}
	
		
	}
	
	@GET
	@Path("/hai")
	public String hi()
	{
		System.out.println("Hello");
		return"welcome to Insecticide page";
	}
	

	@DELETE
	@Path("/delete/{insecticideid}")
	public String deleteit(@PathParam("iid") int x)
	{

			insecticideservice.removeInsecticideService(x);
			
			return "insecticide removed Successfully";
	}
	
	
	
}
