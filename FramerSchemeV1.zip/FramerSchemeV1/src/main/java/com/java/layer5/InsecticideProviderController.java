package com.java.layer5;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.java.layer2.InsecticideProvider;
import com.java.layer4.IInsecticideProviderService;
import com.java.layer4.InsecticideProviderAlreadyExsists;
import com.java.layer4.InsecticideProviderNotFound;
import com.java.layer4.InsecticideProviderServiceImpl;

@Path("/insprodb")
public class InsecticideProviderController {
	
	IInsecticideProviderService ipsi = new InsecticideProviderServiceImpl();
	
	public InsecticideProviderController()
	{
		System.out.println("constructor is called");
		
	}
	
	/*@GET
	@Path("/get/{cid}")
	@Produces(MediaType.APPLICATION_JSON)
	public InsecticideProvider getIt(@PathParam ("cid")int x)
	{
		
		InsecticideProvider in = new InsecticideProvider();
		try {
			in=	ipsi.findInsecticideProviderService(x);
		} catch (InsecticideProviderNotFound e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return in;
		
		
	}*/
	
	@GET
	@Path("/get/{InsecticideProviderId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getInsecticideProvider(@PathParam("InsecticideProviderId") long InsecticiderProviderId) {
		try {
			InsecticideProvider insecticideprovider = ipsi.findInsecticideProviderService(InsecticiderProviderId);
			return Response
					.status(Response.Status.OK)
					.entity(insecticideprovider)
					.build();
		}
		catch(InsecticideProviderNotFound err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	

	@GET
	@Path("/getall")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getallInsecticideprovider(){
		try {
			List<InsecticideProvider> InsecticideProviderList = ipsi.findAllInsecticideProvider();
			return Response
					.status(Response.Status.OK)
					.entity(InsecticideProviderList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@GET
	@Path("/hai")
	public String greet() {
		return "Welcome to inscticide provider Page";
	}
	
	@POST
	@Path("/add")
	public String Addit(InsecticideProvider inspobj)
	{
		try
		{
			ipsi.saveInsecticideProviderService(inspobj);
			return"Insecticide provider is added succesfully";
		}
		catch(InsecticideProviderAlreadyExsists e) {
			 return e.getMessage();
		}
	
		
	}
	
	
	@PUT
	@Path("/update")
	public String updateit(InsecticideProvider inspobj)
	{
		try
		{
			ipsi.modifyInsecticideProviderService(inspobj);
			return "Updated successfully";
		}
		catch(InsecticideProviderNotFound e)
		{
		return e.getMessage();
		}
		
		
	}
	
	@DELETE
	@Path("/delete/{cid}")
	public String deleteit(@PathParam("cid") long x)
	{

			ipsi.removeInsecticideProviderService(x);
			
			return "insecticideProvider deleted";
			
		
		
			
		
		
		
	}
	

}