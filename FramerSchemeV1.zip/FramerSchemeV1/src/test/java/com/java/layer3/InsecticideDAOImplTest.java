package com.java.layer3;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import com.java.layer2.Insecticide;

public class InsecticideDAOImplTest {
	@Test
	public void testAllInsecticides()
	{
		System.out.println("started DAO testing...");
		
	IInsecticideDAO insecticideDao= new InsecticideDAOImpl();
	
		
	Assertions.assertTrue(insecticideDao!=null);
		
		List<Insecticide> insecticideList=insecticideDao.selectAllInsecticide();
	Assertions.assertTrue(insecticideList.size() > 0 );
		
		for (Insecticide insecticide : insecticideList)
		{
			System.out.println("Insecticide : "+insecticide);
		}
	}
	@Test
	public void testSingleInsecticide()
	{
        System.out.println("started testing dao");
		
		IInsecticideDAO insecticideDao= new InsecticideDAOImpl();
		Assertions.assertTrue(insecticideDao!=null);
		
		Insecticide insecticide = insecticideDao.selectInsecticide(2);
		Assertions.assertTrue(insecticide!=null);
		System.out.println("Insecticide"+insecticide);
	}
	
	@Test
	public void testAddSingleInsecticide()
	{
		System.out.println("started testing dao");

		IInsecticideDAO insecticideDao= new InsecticideDAOImpl();
		Assertions.assertTrue(insecticideDao!=null);
		
		Insecticide insecticide = new Insecticide();
		insecticide.setInsecticideId(0);
		insecticide.setInsecticideName(null);
		insecticide.setPrice(0);
		System.out.println("insecticide"+insecticide);
		insecticideDao.insertInsecticide(insecticide);
		System.out.println("currency added");
		
	}
	
	@Test
	public void updateSingleInsecticide()
	{
		System.out.println("started testing dao");
		IInsecticideDAO insecticideDao= new InsecticideDAOImpl();
		Assertions.assertTrue(insecticideDao!=null);
		
		Insecticide insecticide = new Insecticide();
		insecticide.setInsecticideId(1);
		insecticide.setInsecticideName(null);
		insecticide.setPrice(90);
		System.out.println("Insecticide"+insecticide);
		insecticideDao.updateInsecticide(insecticide);
		System.out.println("updated");
		
		
		
		
	}
	
	@Test
	public void deleteSingleInsecticide()
	{
		System.out.println("started testing dao");
		IInsecticideDAO insecticideDao= new InsecticideDAOImpl();
		Assertions.assertTrue(insecticideDao!=null);
		insecticideDao.deleteInsecticide(0);
		System.out.println("deleted");
		
	}
	
}
	

