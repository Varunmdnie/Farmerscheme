package com.java.layer4;

import org.junit.Test;

import com.java.layer2.Insecticide;

public class InsecticideServiceImplTest {
	
	IInsecticideService inservice= new InsecticideServiceImpl();

	
	@Test
	
	public void insecticideAddTest()
	{
		Insecticide insecticide= new Insecticide();
		insecticide.setInsecticideId(5);
		insecticide.setInsecticideName("baran");
		insecticide.setPrice(50);
		
		try {
			inservice.saveInsecticideService(insecticide);
		}
		catch(InsecticideAlreadyExsists e)
		{
			System.out.println("error "+e);
		}
	}
	
	@Test
	public void insecticideModifyTest()
	{
		Insecticide insecticide= new Insecticide();
		insecticide.setInsecticideId(4);
		insecticide.setInsecticideName("baran");
		insecticide.setPrice(50);
		
		try {
			inservice.modifyInsecticideService(insecticide);
		}
		catch(InsecticideNotFound e)
		{
			System.out.println("error "+e);
		}
	}
}
