package com.java.layer2;

import java.util.ArrayList;

public class EquipmentProvider {
	private long equipmentProviderId;
	private String equipmentProviderName;
	private long contact;
	private String emailId;
	private String companyName;
	private float equipmentProviderRating;

	ArrayList<Equipment>equipments;

	public EquipmentProvider() {
		System.out.println("EquipmentProvider Constructor().....");
	}

	
	public long getEquipmentProviderId() {
		return equipmentProviderId;
	}


	public String getEquipmentProviderName() {
		return equipmentProviderName;
	}


	public long getContact() {
		return contact;
	}


	public String getEmailId() {
		return emailId;
	}


	public String getCompanyName() {
		return companyName;
	}


	public float getEquipmentProviderRating() {
		return equipmentProviderRating;
	}


	public ArrayList<Equipment> getEquipments() {
		return equipments;
	}


	public void setEquipmentProviderId(long equipmentProviderId) {
		this.equipmentProviderId = equipmentProviderId;
	}


	public void setEquipmentProviderName(String equipmentProviderName) {
		this.equipmentProviderName = equipmentProviderName;
	}


	public void setContact(long contact) {
		this.contact = contact;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}


	public void setEquipmentProviderRating(float equipmentProviderRating) {
		this.equipmentProviderRating = equipmentProviderRating;
	}


	public void setEquipments(ArrayList<Equipment> equipments) {
		this.equipments = equipments;
	}


	@Override
	public String toString() {
		return "EquipmentProvider [toString()=" + super.toString() + ", equipmentProviderId=" + equipmentProviderId
				+ ", equipmentProviderName=" + equipmentProviderName + ", contact=" + contact + ", emailId=" + emailId
				+ ", companyName=" + companyName + ", equipmentProviderRating=" + equipmentProviderRating
				+ ", equipments=" + equipments + "]";
	}
	
	
	
	
	
	
}

