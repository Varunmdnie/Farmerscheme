package com.java.layer2;

public class FarmerAndCrop {
	
	long farmerId;
	int cropId;
	

	public long getFarmerId() {
		return farmerId;
	}


	public void setFarmerId(long farmerId) {
		this.farmerId = farmerId;
	}


	public int getCropId() {
		return cropId;
	}


	public void setCropId(int cropId) {
		this.cropId = cropId;
	}


	public FarmerAndCrop(long farmerId, int cropId) {
		super();
		this.farmerId = farmerId;
		this.cropId = cropId;
	}


	public FarmerAndCrop() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public String toString() {
		return "FarmerAndCrop [farmerId=" + farmerId + ", cropId=" + cropId + "]";
	}
	

}
