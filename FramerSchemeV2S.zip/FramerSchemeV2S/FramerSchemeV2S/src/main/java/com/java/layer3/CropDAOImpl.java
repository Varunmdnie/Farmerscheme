package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.Crop;

public class CropDAOImpl implements ICropDAO {
	Connection conn;

	public CropDAOImpl() {
		try {
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			System.out.println("1. driver...loaded");
			System.out.println("Trying to connect to the DB...");
			this.conn = DriverManager.getConnection("jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
			System.out.println("2. Connected to the DB :" + conn);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Crop selectCrop(int cropId) {
		// TODO Auto-generated method stub
		Crop crop = null; // make a blank currency object

		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM Crop where cropId=" + cropId);
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			if (result.next()) {

				crop = new Crop(cropId, null);
				crop.setCropId(result.getInt(1)); // fill it up column wise
				crop.setCropName(result.getString(2));

			}
		} catch (SQLException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return crop;
	}

	@Override
	public List<Crop> selectAllCrops() {
		List<Crop> cropList = new ArrayList<Crop>();// blank list

		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM Crop");
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			while (result.next()) {
				Crop crop = new Crop(0, null);
				crop.setCropId(result.getInt(1));
				crop.setCropName(result.getString(2));

				cropList.add(crop);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cropList;
	}

	@Override
	public void insertCrop(Crop crop) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into Crop(cropId,cropName) values(?,?,?)");
			System.out.println("3. PreparedStatement created....");

			pst.setInt(1, crop.getCropId());
			pst.setString(2, crop.getCropName());

			int rows = pst.executeUpdate(); // run the insert query

			System.out.println("4. executed the insert query : " + rows + " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void updateCrop(Crop crop) {

		// TODO Auto-generated catch block

		// TODO Auto-generated method stub

	}

	@Override
	public void deleteCrop(int cropId) {
		// TODO Auto-generated method stub

	}

	@Override
	public Crop selectCropByName(String cropName) {
		// TODO Auto-generated method stub
		Crop crop = null; // make a blank currency object

		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM Crop where cropName like'" + cropName+"';");
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			if (result.next()) {

				crop = new Crop(0,cropName);
				crop.setCropId(result.getInt(1)); // fill it up column wise
				crop.setCropName(result.getString(2));

			}
		} catch (SQLException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return crop;
	}
}
