package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.java.layer2.CropForSale;


public class CropForSaleDAOImpl implements ICropForSaleDAO {
	Connection conn;

	public CropForSaleDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public CropForSale selectCropForSale(long cropForSaleId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CropForSale> selectAllCropsForSale() {
    List<CropForSale> cropForSaleList = new ArrayList<CropForSale>();//blank list
		
		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM CropForSale"); //eid, ename, job, sal    cid,cname,city,pin
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			while (result.next()) {
				CropForSale cropForSale = new CropForSale(); //make a blank currency object
				cropForSale.setCropForSaleId(result.getLong(1)); //fill it up column wise
				cropForSale.setFarmerId(result.getLong(2));
				cropForSale.setCropId(result.getInt(3));
				cropForSale.setQuantity(result.getFloat(4));
				cropForSale.setMinimumPrice(result.getFloat(5));
				cropForSale.setTimeUpload(result.getDate(6));
				
				cropForSaleList.add(cropForSale); //push this object in the list
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cropForSaleList;
	}

	@Override
	public void insertCropForSale(CropForSale cropForSale) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into cropForSale(cropId,farmerId,quantity,minimumPrice,timeUpload) values(?,?,?,?,?)");
			System.out.println("3. PreparedStatement created....");

			
			
			pst.setInt(1, cropForSale.getCropId());
			pst.setLong(2, cropForSale.getFarmerId());
			pst.setFloat(3, cropForSale.getQuantity());
			pst.setFloat(4, cropForSale.getMinimumPrice());
			pst.setDate(5, cropForSale.getTimeUpload());
			
			

			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void updateCropForSale(CropForSale cropForSale) {
		try {
			PreparedStatement pst = conn.prepareStatement("UPDATE CropForSale set cropId=?, farmerId=?, quantity=? ,minimumPrice=? ,timeUpload=? where cropForSaleId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setInt(1, cropForSale.getCropId());
			pst.setLong(2, cropForSale.getFarmerId());
			pst.setFloat(3, cropForSale.getQuantity());
			pst.setFloat(4, cropForSale.getMinimumPrice());
			pst.setDate(5, cropForSale.getTimeUpload());
			pst.setLong(6, cropForSale.getCropForSaleId());
			


			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the update query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}


	@Override
	public void deleteCropForSale(long cropForSaleId) {
		try {
			PreparedStatement pst = conn.prepareStatement("DELETE FROM CropForSale where cropForSaleId=?");
			System.out.println("3. PreparedStatement created....");

			
			pst.setLong(1, cropForSaleId);
			
			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the delete query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}


}


