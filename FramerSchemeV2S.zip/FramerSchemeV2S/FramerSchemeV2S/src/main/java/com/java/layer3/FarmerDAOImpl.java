package com.java.layer3;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import com.java.layer2.Farmer;

public class FarmerDAOImpl implements IFarmerDAO {
	Connection conn;

	public FarmerDAOImpl() {
			try {
				System.out.println("Trying to load the driver...");
				DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
				System.out.println("1. driver...loaded");
				System.out.println("Trying to connect to the DB...");
				this.conn = DriverManager.getConnection("jdbc:mysql://10.93.14.52/FarmerSchemeV1", "root", "root123");
				System.out.println("2. Connected to the DB :" + conn);
			} catch (SQLException e) {e.printStackTrace();}
	}

	@Override
	public Farmer selectFarmer(long farmerId) {
		
		Farmer farmer = null; // make a blank currency object

		try {
			Statement statement = conn.createStatement();
			System.out.println("3. Statement created....");
			ResultSet result = statement.executeQuery("SELECT * FROM FarmerDetails where farmerId=" + farmerId);
			System.out.println("4. execute the query");

			System.out.println("5. acquire the result and process it");

			if (result.next()) {

				farmer = new Farmer();
				farmer.setFarmerId(result.getLong(1)); // fill it up column wise
				farmer.setFarmerName(result.getString(2));
				farmer.setContact(result.getLong(3));
				farmer.setCity(result.getString(4));
				farmer.setEmailId(result.getString(5));
				farmer.setFarmerRating(result.getFloat(6));

			}
		} catch (SQLException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return farmer;
	}
		// TODO Auto-generated method stub
	
	@Override
	public List<Farmer> selectAllFarmers() {
	    List<Farmer> farmerList = new ArrayList<Farmer>();//blank list
		
			try {
				Statement statement = conn.createStatement();
				System.out.println("3. Statement created....");
				ResultSet result = statement.executeQuery("SELECT * FROM FarmerDetails"); 
				System.out.println("4. execute the query");

				System.out.println("5. acquire the result and process it");

				while (result.next()) {
					Farmer farmer = new Farmer(); //
					farmer.setFarmerId(result.getLong(1)); // fill it up column wise
					farmer.setFarmerName(result.getString(2));
					farmer.setContact(result.getLong(3));
					farmer.setCity(result.getString(4));
					farmer.setEmailId(result.getString(5));
					farmer.setFarmerRating(result.getFloat(6));

					
					farmerList.add(farmer); //push this object in the list
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return farmerList;
		}

	@Override
	public void insertFarmer(Farmer farmer) {
		try {
			PreparedStatement pst = conn.prepareStatement("insert into FarmerDetails(farmerId,farmerName,contact,city,emailId,farmerRating) values(?,?,?,?,?,?)");
			System.out.println("3. PreparedStatement created....");

			
			
			pst.setLong(1, farmer.getFarmerId());
			pst.setString(2, farmer.getFarmerName());
			pst.setLong(3, farmer.getContact());
			pst.setString(4, farmer.getCity());
			pst.setString(5, farmer.getEmailId());
			pst.setFloat(6, farmer.getFarmerRating());
			
			

			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the insert query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	@Override
	public void updateFarmer(Farmer farmer) {
		try {
		PreparedStatement pst = conn.prepareStatement("UPDATE FarmerDetails set  farmerName=?, contact=?,city=?,emailId=?,farmerRating=? where farmerId=?");
		System.out.println("3. PreparedStatement created....");

		pst.setString(1, farmer.getFarmerName());
		pst.setLong(2, farmer.getContact());
		pst.setString(3, farmer.getCity());
		
		pst.setString(4, farmer.getEmailId());
		pst.setFloat(5, farmer.getFarmerRating());
		pst.setLong(6, farmer.getFarmerId());

		int rows = pst.executeUpdate(); //run the insert query
		
		System.out.println("4. executed the update query : "+rows+ " row(s) updated");
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
}

	@Override
	public void deleteFarmer(long farmerId) {
		try {
			PreparedStatement pst = conn.prepareStatement("DELETE FROM FarmerDetails where farmerId=?");
			System.out.println("3. PreparedStatement created....");

			pst.setLong(1, farmerId);
			
			int rows = pst.executeUpdate(); //run the insert query
			
			System.out.println("4. executed the delete query : "+rows+ " row(s) updated");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}

	
	
	}
	


	
	
	
	


