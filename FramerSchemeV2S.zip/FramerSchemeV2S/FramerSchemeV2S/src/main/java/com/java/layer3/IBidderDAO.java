package com.java.layer3;

import java.util.List;

import com.java.layer2.Bidder;

public interface IBidderDAO {
	public void insertBidder(Bidder e);
	public List<Bidder> selectAllBidders();
	public Bidder selectBidder(long bidderId);
	public void updateBidder(Bidder e);
	public void deleteBidder(long bidderId);
}
