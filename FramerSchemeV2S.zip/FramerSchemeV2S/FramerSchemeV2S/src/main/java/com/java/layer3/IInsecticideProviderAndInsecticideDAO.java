package com.java.layer3;

import java.util.List;

import com.java.layer2.InsecticideProviderAndInsecticide;



public interface IInsecticideProviderAndInsecticideDAO {
	

	InsecticideProviderAndInsecticide selectInsecticideProviderAndInsecticide(long InsecticideProviderId,int InsecticideId);
	List<InsecticideProviderAndInsecticide> selectAllInsecticideProviderAndInsecticide();
	
	void insertInsecticideProviderAndInsecticide(InsecticideProviderAndInsecticide insecticideproviderandinsecticide);
	void updateInsecticideProviderAndInsecticide(InsecticideProviderAndInsecticide insecticideproviderandinsecticide);
	void deleteInsecticideProviderAndInsecticide(long InsecticideProviderId,int InsecticideId);


}
