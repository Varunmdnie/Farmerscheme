package com.java.layer4;

public class BidderNotFoundException extends Exception {
	public BidderNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
