package com.java.layer4;

import java.util.List;

import com.java.layer2.Bid;
import com.java.layer2.Bidder;
import com.java.layer2.CropForSale;
import com.java.layer2.SuccessfulTransaction;

public interface IBidderService {
	List<Bidder> findAllBidderService();
	Bidder findBidderService(long bidderId) throws BidderNotFoundException;
	void insertBidderService(Bidder b) throws BidderAlreadyExistException;
	void removeBidderService(long bidderId) throws BidderNotFoundException;
	void modifyBidderService(Bidder b) throws BidderNotFoundException;
	List<CropForSale> showAllCropForSaleService();
	List<SuccessfulTransaction> showAllBidderTransactionService(long bidderId) throws TransactionNotFoundException;
	void doBid(long bidderId,long cropForSaleId,float amount);
	Bid getBid(long bidId)  throws BidNotFoundException;
	List<Bid> getBids(long bidderId) throws BidsNotFoundException;
}
