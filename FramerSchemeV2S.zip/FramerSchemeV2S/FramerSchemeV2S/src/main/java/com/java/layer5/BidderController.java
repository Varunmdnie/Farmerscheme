package com.java.layer5;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.java.layer2.Bid;
import com.java.layer2.Bidder;
import com.java.layer2.CropForSale;
import com.java.layer4.BidderServiceImpl;
import com.java.layer4.IBidderService;

@Path("/bidder")
public class BidderController {
	
	IBidderService bidderService = new BidderServiceImpl();

	public BidderController() {
		// TODO Auto-generated constructor stub
		System.out.println("Bidder controller called....");
	}
	
	@GET
	@Path("/greet")
	public String greet() {
		return "<h1>Greetings to the bidders</h1>";
	}
	
	@GET
	@Path("/all")
	@Produces(MediaType.APPLICATION_JSON)
	public Response allBidders(){
		try {
			List<Bidder> bidderList = bidderService.findAllBidderService();
			return Response
					.status(Response.Status.OK)
					.entity(bidderList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@GET
	@Path("/all/{bidderId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getBidder(@PathParam("bidderId") long bidderId) {
		try {
			Bidder bidder = bidderService.findBidderService(bidderId);
			return Response
					.status(Response.Status.OK)
					.entity(bidder)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@POST
	@Path("/addBidder")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addBidder(Bidder b) {
		try {
			System.out.println(b);
			System.out.println("Inside add bidder");
			bidderService.insertBidderService(b);
			List<Bidder> bidderList = bidderService.findAllBidderService();
			return Response
					.status(Response.Status.OK)
					.entity(bidderList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@PUT
	@Path("/modifyBidder")
	@Produces(MediaType.APPLICATION_JSON)
	public Response modifyBidder(Bidder b) {
		try {
			bidderService.modifyBidderService(b);
			List<Bidder> bidderList = bidderService.findAllBidderService();
			return Response
					.status(Response.Status.OK)
					.entity(bidderList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@DELETE
	@Path("/deleteBidder/{bidderId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteBidder(@PathParam("bidderId") long bidderId) {
		try {
			bidderService.removeBidderService(bidderId);
			List<Bidder> bidderList = bidderService.findAllBidderService();
			return Response
					.status(Response.Status.OK)
					.entity(bidderList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@GET
	@Path("/allCropForSale")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllCropForSale() {
		try {
			List<CropForSale> cropForSaleList = bidderService.showAllCropForSaleService();
			
			return Response
					.status(Response.Status.OK)
					.entity(cropForSaleList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@GET
	@Path("/allbids/{bidderId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAllBidsOfBidder(@PathParam("bidderId") long bidderId) {
		try {
			List<Bid> bidList = bidderService.getBids(bidderId);
			return Response
					.status(Response.Status.OK)
					.entity(bidList)
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
	@POST
	@Path("/addBid/{bidderId}/{cropForSaleId}/{amount}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response addBid(@PathParam("bidderId") long bidderId,@PathParam("cropForSaleId") long cropForSaleId,@PathParam("amount") float amount) {
		try {
			System.out.println(bidderId + " " + cropForSaleId + " " + amount);
			bidderService.doBid(bidderId, cropForSaleId, amount);
			return Response
					.status(Response.Status.OK)
					.entity("Bid added")
					.build();
		}
		catch(Exception err) {
			System.out.println(err);
			return Response
					.status(Response.Status.NOT_FOUND)
					.entity(null)
					.build();
		}
	}
	
}
