package com.java.layer3;

import java.sql.Date;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.layer2.CropForSale;


public class CropForSaleDAOImplTest {
	@Test
	public void testAllCropForSale()
	{
		System.out.println("started DAO testing...");
		
		ICropForSaleDAO cropForSaleDao= new CropForSaleDAOImpl();
		
			
		Assertions.assertTrue(cropForSaleDao!=null);
			
		List<CropForSale> cropForSaleList=cropForSaleDao.selectAllCropsForSale();
		Assertions.assertTrue(cropForSaleList.size() > 0 );
		
		for (CropForSale cropForSale : cropForSaleList) {
			System.out.println("Crop FOr Sale : "+cropForSale);
		}
	
	}
	@Test
	public void testAddSingleCropForSale()
	{
		System.out.println("started DAO testing...");
		
		ICropForSaleDAO cropForSaleDao = new CropForSaleDAOImpl();	
		Assertions.assertTrue(cropForSaleDao!=null);
			
		CropForSale cropForSale=new CropForSale();
		Assertions.assertTrue(cropForSale!=null);
		
		cropForSale.setFarmerId(515557953362l);
		cropForSale.setCropId(2);
		cropForSale.setQuantity(30);
		cropForSale.setMinimumPrice(12000);
		cropForSale.setTimeUpload(Date.valueOf("2023-03-21"));
	
		
		System.out.println("Crops For sale : "+cropForSale);
		cropForSaleDao.insertCropForSale(cropForSale);
		System.out.println("Crop for sale added....");
	}
	
	
	
	

}
