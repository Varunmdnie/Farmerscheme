package com.java.layer3;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.layer2.FarmerAndCrop;

public class FarmerAndCropDAOImplTest {
	@Test
	public void testAddSingleFarmerAndCrop()
	{
		System.out.println("started DAO testing...");
		
		IFarmerAndCropDAO dao = new FarmerAndCropDAOImpl();	
	Assertions.assertTrue(dao!=null);
		
		FarmerAndCrop farmer=new FarmerAndCrop();
	Assertions.assertTrue(farmer!=null);
	
		
		farmer.setFarmerId(515557953362l);
		farmer.setCropId(2);
		
		System.out.println("Farmer : "+farmer);
		dao.insertFarmerAndCrop(farmer);
		System.out.println("Farmer added....");
	}
	@Test
	public void testAllFarmerAndCrop()
	{
		System.out.println("started DAO testing...");
		
	IFarmerAndCropDAO dao= new FarmerAndCropDAOImpl();
	
		
	Assertions.assertTrue(dao!=null);
		
		List<FarmerAndCrop> farmerAndCropList=dao.selectAllFarmerAndCrops();
	Assertions.assertTrue(farmerAndCropList.size() > 0 );
		
		for (FarmerAndCrop farmer : farmerAndCropList) {
			System.out.println("Farmer : "+farmer);
		}
	
	}
}
