package com.java.layer3;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import com.java.layer2.Farmer;



public class FarmerDAOImplTest {
	@Test
	public void testAllFarmers()
	{
		System.out.println("started DAO testing...");
		
	IFarmerDAO farmerDao= new FarmerDAOImpl();
	
		
	Assertions.assertTrue(farmerDao!=null);
		
		List<Farmer> farmerList=farmerDao.selectAllFarmers();
	Assertions.assertTrue(farmerList.size() > 0 );
		
		for (Farmer farmer : farmerList) {
			System.out.println("Farmer : "+farmer);
		}
	
	}
	@Test
	public void testAddSingleFarmer()
	{
		System.out.println("started DAO testing...");
		
		IFarmerDAO farmerDao = new FarmerDAOImpl();	
	Assertions.assertTrue(farmerDao!=null);
		
		Farmer farmer=new Farmer();
	Assertions.assertTrue(farmer!=null);
	
		
		farmer.setFarmerId(515557953362l);
		farmer.setFarmerName("Mukhil");
		farmer.setContact(9842561871l);
		farmer.setCity("Coimbatore");
		farmer.setEmailId("mukhil2011@gmail.com");
		farmer.setFarmerRating(4.5f);
		
		System.out.println("Farmer : "+farmer);
		farmerDao.insertFarmer(farmer);
		System.out.println("Farmer added....");
	}
	
	@Test
	public void testUpdateSingleCurrency()
	{
		System.out.println("started DAO testing...");
		
		IFarmerDAO farmerDao = new FarmerDAOImpl();	
	Assertions.assertTrue(farmerDao!=null);
		
		Farmer farmer=new Farmer();
	Assertions.assertTrue(farmer!=null);
	
	    farmer.setFarmerId(515557953362l);
		farmer.setFarmerName("Mukhil Sarvesh S");
		farmer.setContact(9842561871l);
		farmer.setCity("Coimbatore");
		farmer.setEmailId("mukhil2011@gmail.com");
		farmer.setFarmerRating(4.5f);
		
		System.out.println("Farmer : "+farmer);
		farmerDao.updateFarmer(farmer);
		System.out.println("Farmer updated....");
	}
	
	@Test
	public void testDeleteSingleFarmer()
	{
		System.out.println("started DAO testing...");
		
		IFarmerDAO farmerDao = new FarmerDAOImpl();	
	Assertions.assertTrue(farmerDao!=null);
		
		farmerDao.deleteFarmer(515557953362l);
		System.out.println	("Farmer deleted....");
	}
	

	

}
