package com.java.layer3;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import com.java.layer2.Insecticide;

public class InsecticideDAOImplTest {
	@Test
	public void testAllInsecticides()
	{
		System.out.println("started DAO testing...");
		
	IInsecticideDAO insecticideDao= new InsecticideDAOImpl();
	
		
	Assertions.assertTrue(insecticideDao!=null);
		
		List<Insecticide> insecticideList=insecticideDao.selectAllInsecticide();
	Assertions.assertTrue(insecticideList.size() > 0 );
		
		for (Insecticide insecticide : insecticideList) {
			System.out.println("Insecticide : "+insecticide);
		}
	}
}
	

