package com.java.layer4;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.layer2.Bidder;

public class BidderServiceImplTest {

	@Test
	public void testAllBidders(){
		System.out.println("started DAO testing...");
		
		IBidderService bidderService = new BidderServiceImpl();
		
			
		Assertions.assertTrue(bidderService!=null);
			
		List<Bidder> bidderList=bidderService.findAllBidderService();
		Assertions.assertTrue(bidderList.size() > 0 );
		
		for (Bidder bidder : bidderList) {
			System.out.println("Bidder : " + bidder);
		}
	}

}
